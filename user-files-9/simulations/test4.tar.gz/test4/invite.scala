package test4

import scala.concurrent.duration._

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._
import Trait._
object Invite2 extends Trait{
	val invite2=exec(http("Invite Guest")
			.get("/_matrix/client/r0/sync?filter=2&timeout=30000&since=s1539_1238_764_7_1_2&access_token=MDAyMGxvY2F0aW9uIG1hdHJpeC5hbGxtZW5kZS5pbwowMDEzaWRlbnRpZmllciBrZXkKMDAxMGNpZCBnZW4gPSAxCjAwMmRjaWQgdXNlcl9pZCA9IEB0ZXN0MDE6bWF0cml4LmFsbG1lbmRlLmlvCjAwMTZjaWQgdHlwZSA9IGFjY2VzcwowMDFkY2lkIHRpbWUgPCAxNDY4NDI4MDc4NDA3CjAwMmZzaWduYXR1cmUgyG_9m8GvGpt4ENchxqZDYMFxvDriOQLwlgHOUA_a2tcK")
			.headers(headers_14)
			.check(status.is(200)))
		.pause(8)
	}
