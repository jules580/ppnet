 package test4
 import scala.concurrent.duration._
 
 import io.gatling.core.Predef._
 import io.gatling.http.Predef._
 import io.gatling.jdbc.Predef._
 
 import Trait._
 object SendInvitation2 extends Trait{
 val feeder=csv("login2.csv").random
		val sendinvitation2=exec(feed(feeder))
		.exec(http("Rooms Infos")
			.options("/_matrix/client/r0/rooms/!ipQwPggUIzFhkhpiOI%3Amatrix.allmende.io/invite?access_token=MDAyMGxvY2F0aW9uIG1hdHJpeC5hbGxtZW5kZS5pbwowMDEzaWRlbnRpZmllciBrZXkKMDAxMGNpZCBnZW4gPSAxCjAwMmRjaWQgdXNlcl9pZCA9IEB0ZXN0MDE6bWF0cml4LmFsbG1lbmRlLmlvCjAwMTZjaWQgdHlwZSA9IGFjY2VzcwowMDFkY2lkIHRpbWUgPCAxNDY4NDI4MDc4NDA3CjAwMmZzaWduYXR1cmUgyG_9m8GvGpt4ENchxqZDYMFxvDriOQLwlgHOUA_a2tcK")
			.headers(headers_11)
			.resources(http("Send Invitation")
			.post("/_matrix/client/r0/rooms/!ipQwPggUIzFhkhpiOI%3Amatrix.allmende.io/invite?access_token=MDAyMGxvY2F0aW9uIG1hdHJpeC5hbGxtZW5kZS5pbwowMDEzaWRlbnRpZmllciBrZXkKMDAxMGNpZCBnZW4gPSAxCjAwMmRjaWQgdXNlcl9pZCA9IEB0ZXN0MDE6bWF0cml4LmFsbG1lbmRlLmlvCjAwMTZjaWQgdHlwZSA9IGFjY2VzcwowMDFkY2lkIHRpbWUgPCAxNDY4NDI4MDc4NDA3CjAwMmZzaWduYXR1cmUgyG_9m8GvGpt4ENchxqZDYMFxvDriOQLwlgHOUA_a2tcK")
			.headers(headers_12)
			.body(RawFileBody("RecordedSimulateCreatePrivateRoomVector_0062_request.txt"))
			.check(status.is(200)),
            http("f4c371 image")
			.get("http://" + uri1 + ":8081/img/f4c371.png")
			.headers(headers_63)
			.check(status.is(304)))
			.check(status.is(200)))
			.exec(session => {
				println("session"+session)
				session
			})
		}
