package test4
import scala.concurrent.duration._
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._
import Trait._
object Param2 extends Trait{
	val param2=exec(http("Param initial")
			.options("/_matrix/client/r0/rooms/!BgUjAJRcsCqJwfjbUw%3Amatrix.allmende.io/state/m.room.power_levels/?access_token=MDAyMGxvY2F0aW9uIG1hdHJpeC5hbGxtZW5kZS5pbwowMDEzaWRlbnRpZmllciBrZXkKMDAxMGNpZCBnZW4gPSAxCjAwMmRjaWQgdXNlcl9pZCA9IEB0ZXN0MDk6bWF0cml4LmFsbG1lbmRlLmlvCjAwMTZjaWQgdHlwZSA9IGFjY2VzcwowMDFkY2lkIHRpbWUgPCAxNDY4NDI4MjA2MDU2CjAwMmZzaWduYXR1cmUgBQGM8CyAqBPp-he2008p0kl8hVjwadjzbGvZ_GtO3T8K")
			.headers(headers_13)
			.resources(http("Set Param")
			.put("/_matrix/client/r0/rooms/!BgUjAJRcsCqJwfjbUw%3Amatrix.allmende.io/state/m.room.power_levels/?access_token=MDAyMGxvY2F0aW9uIG1hdHJpeC5hbGxtZW5kZS5pbwowMDEzaWRlbnRpZmllciBrZXkKMDAxMGNpZCBnZW4gPSAxCjAwMmRjaWQgdXNlcl9pZCA9IEB0ZXN0MDk6bWF0cml4LmFsbG1lbmRlLmlvCjAwMTZjaWQgdHlwZSA9IGFjY2VzcwowMDFkY2lkIHRpbWUgPCAxNDY4NDI4MjA2MDU2CjAwMmZzaWduYXR1cmUgBQGM8CyAqBPp-he2008p0kl8hVjwadjzbGvZ_GtO3T8K")
			.headers(headers_16)
			.body(RawFileBody("RecordedSimulateSendMessageVector_0054_request.txt"))
			.check(status.is(200)),
            http("setting image")
			.get("http://" + uri1 + ":8081/img/settings.svg")
			.headers(headers_23)
			.check(status.is(304)),
            http("leave image")
			.get("http://" + uri1 + ":8081/img/leave.svg")
			.headers(headers_42)
			.check(status.is(304)),
            http("search image")
			.get("http://" + uri1 + ":8081/img/search.svg")
			.headers(headers_24)
			.check(status.is(304)),
            http("Liste event")
			.get("/_matrix/client/r0/sync?filter=0&timeout=30000&since=s1547_1239_764_7_1_2&access_token=MDAyMGxvY2F0aW9uIG1hdHJpeC5hbGxtZW5kZS5pbwowMDEzaWRlbnRpZmllciBrZXkKMDAxMGNpZCBnZW4gPSAxCjAwMmRjaWQgdXNlcl9pZCA9IEB0ZXN0MDk6bWF0cml4LmFsbG1lbmRlLmlvCjAwMTZjaWQgdHlwZSA9IGFjY2VzcwowMDFkY2lkIHRpbWUgPCAxNDY4NDI4MjA2MDU2CjAwMmZzaWduYXR1cmUgBQGM8CyAqBPp-he2008p0kl8hVjwadjzbGvZ_GtO3T8K")
			.headers(headers_14)
			.check(status.is(200)),
            http("member image")
			.get("http://" + uri1 + ":8081/img/member_chevron.png")
			.headers(headers_59)
			.check(status.is(304)))
			.check(status.is(200)))
		.pause(24)
	}
