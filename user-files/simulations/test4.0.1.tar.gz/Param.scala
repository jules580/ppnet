package test4
import scala.concurrent.duration._
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._
import Trait._
object Param2 extends Trait{
	val param2=exec(http("Camera Image")
			.get("http://" + uri1 + ":8081/img/camera.svg")
			.headers(headers_50)
			.resources(http("Visibility ")
			.get("/_matrix/client/r0/directory/list/room/${table}%3Amatrix.allmende.io?access_token=${token}")
			.headers(headers_14)
			.check(status.is(200)),
            http("tick image")
			.get("http://" + uri1 + ":8081/img/tick.svg")
			.headers(headers_52)
			.check(status.is(304)))
			.check(status.is(304)))
		.pause(17)
	}
