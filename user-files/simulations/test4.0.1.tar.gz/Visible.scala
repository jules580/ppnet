package test4
import scala.concurrent.duration._

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._
import Trait._

object Visible2 extends Trait{

	val visible2=exec(http("Visibility room")
			.get("/_matrix/client/r0/directory/list/room/!BgUjAJRcsCqJwfjbUw%3Amatrix.allmende.io?access_token=MDAyMGxvY2F0aW9uIG1hdHJpeC5hbGxtZW5kZS5pbwowMDEzaWRlbnRpZmllciBrZXkKMDAxMGNpZCBnZW4gPSAxCjAwMmRjaWQgdXNlcl9pZCA9IEB0ZXN0MDk6bWF0cml4LmFsbG1lbmRlLmlvCjAwMTZjaWQgdHlwZSA9IGFjY2VzcwowMDFkY2lkIHRpbWUgPCAxNDY4NDI4MjA2MDU2CjAwMmZzaWduYXR1cmUgBQGM8CyAqBPp-he2008p0kl8hVjwadjzbGvZ_GtO3T8K")
			.headers(headers_14)
			.resources(http("camera image")
			.get("http://" + uri1 + ":8081/img/camera.svg")
			.headers(headers_51)
			.check(status.is(304)),
            http("tick image")
			.get("http://" + uri1 + ":8081/img/tick.svg")
			.headers(headers_52)
			.check(status.is(304)))
			.check(status.is(200)))
		.pause(8)
	}
	
