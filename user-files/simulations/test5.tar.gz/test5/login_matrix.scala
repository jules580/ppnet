 package test5
 
 import scala.concurrent.duration._
 import io.gatling.core.Predef._
 import io.gatling.http.Predef._
 import io.gatling.jdbc.Predef._
 import Trait_Matrix._
 
 object Login_Matrix2 extends Trait_Matrix{
	 val feeder=csv("login.csv").random
	 val login_matrix2=exec(feed(feeder))
		.exec(http("login")
			.post("/_matrix/client/api/v1/login")
			.headers(headers_9) 
			.body(StringBody("""{"user":"${login}","password":"${password}","type":"m.login.password"}"""))
			.resources(http("Home user")
			.get("/_matrix/client/app/home/home.html")
			.check(status.is(200)),
        
            http("Logo-small")
			.get("/_matrix/client/img/logo-small.png")
			.headers(headers_11)
			.check(status.is(200)),
            http("TurnServer Access")
			.get("/_matrix/client/api/v1/voip/turnServer?access_token=MDAyMGxvY2F0aW9uIG1hdHJpeC5hbGxtZW5kZS5pbwowMDEzaWRlbnRpZmllciBrZXkKMDAxMGNpZCBnZW4gPSAxCjAwMmRjaWQgdXNlcl9pZCA9IEB0ZXN0cmU6bWF0cml4LmFsbG1lbmRlLmlvCjAwMTZjaWQgdHlwZSA9IGFjY2VzcwowMDFkY2lkIHRpbWUgPCAxNDY3NzEzNDk5Nzc3CjAwMmZzaWduYXR1cmUghKHurGRshGS0dpwu2WqEV3C8Pshl-KoZEs_wGWHzx-8K")
			.headers(headers_12)
			.check(status.is(200)),
            http("DisplayName")
			.get("/_matrix/client/api/v1/profile/%40testre%3Amatrix.allmende.io/displayname?access_token=MDAyMGxvY2F0aW9uIG1hdHJpeC5hbGxtZW5kZS5pbwowMDEzaWRlbnRpZmllciBrZXkKMDAxMGNpZCBnZW4gPSAxCjAwMmRjaWQgdXNlcl9pZCA9IEB0ZXN0cmU6bWF0cml4LmFsbG1lbmRlLmlvCjAwMTZjaWQgdHlwZSA9IGFjY2VzcwowMDFkY2lkIHRpbWUgPCAxNDY3NzEzNDk5Nzc3CjAwMmZzaWduYXR1cmUghKHurGRshGS0dpwu2WqEV3C8Pshl-KoZEs_wGWHzx-8K")
			.headers(headers_12)
			.check(status.is(200)),
            http("Get public Room")
			.get("/_matrix/client/api/v1/publicRooms")
			.headers(headers_12)
			.check(status.is(200)),
            http("profile info")
			.get("/_matrix/client/api/v1/profile/%40testre%3Amatrix.allmende.io/avatar_url?access_token=MDAyMGxvY2F0aW9uIG1hdHJpeC5hbGxtZW5kZS5pbwowMDEzaWRlbnRpZmllciBrZXkKMDAxMGNpZCBnZW4gPSAxCjAwMmRjaWQgdXNlcl9pZCA9IEB0ZXN0cmU6bWF0cml4LmFsbG1lbmRlLmlvCjAwMTZjaWQgdHlwZSA9IGFjY2VzcwowMDFkY2lkIHRpbWUgPCAxNDY3NzEzNDk5Nzc3CjAwMmZzaWduYXR1cmUghKHurGRshGS0dpwu2WqEV3C8Pshl-KoZEs_wGWHzx-8K")
			.headers(headers_12)
			.check(status.is(200)),
            http("Info recent event")
			.get("/_matrix/client/app/recents/recents.html")
			.check(status.is(200))
			.check(currentLocation.saveAs("ccurrentLocation"))
			.check(responseTimeInMillis.saveAs("responseTime"))
			.check(regex("""https://(.*)/.*""").count.saveAs("Https")),
			//.check(bodyString.saveAs("bodystring"))
			//.check(bodyBytes.saveAs("bodybytes")),
            http("Close picture")
			.get("/_matrix/client/img/close.png")
			.headers(headers_11)
			.check(status.is(200)))
			.check(status.is(200)))
			
			.exec(session =>{
				println ("session"+session)
				session
			})
 }
 
