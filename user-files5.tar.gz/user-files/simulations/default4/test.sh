#!/bin/sh

text=$(grep -i " " RecordedSimulateloginFalse.scala)
echo $text
