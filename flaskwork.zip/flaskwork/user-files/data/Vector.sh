#!/bin/bash

echo "login,password,table,token" > login.csv
./listVector4.sh testre
./listVector4.sh test456
./listVector4.sh test01
./listVector4.sh test03
#./listVector4.sh testres


